package binary_search;

public class ElementNotFoundException extends Exception{
	
	public ElementNotFoundException() {
		super();
	}
	
	public ElementNotFoundException(String message) {
		super(message);
	}

}
